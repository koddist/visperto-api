export enum VisaCountriesEnum {
  LENGTH_OF_COUNTRIES = 199,
  REST_COUNTRIES_API_URL = 'https://restcountries.com/v3.1/all',
  TEST_COUNTRY = 'Israel',
  TEST_TRAVEL_TO_COUNTRY = 'Iran',
  TEST_VISA_STATUS = 'not admitted',
}
