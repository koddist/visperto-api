export interface WeatherInterface {
  temperature: number;
  windspeed: number;
  winddirection: number;
  weathercode: number;
  time: string;
}
